<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IFM Tracking Web | Register</title>
    <link href="style.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>

<div class="video">
            <video class="video" autoplay loop muted plays-inline>
             <source src="stud.mp4" type="video/mp4">
            </video>
     </div>

<?php 
	require "functions.php";
	regUser();
?>
    
    <div class="form-register">
        <form action="" method="POST">
             <h2>Sign Up Here</h2>
             <input type="text" name="username" placeholder="Username" required>
             <input type="email" name="email" placeholder="Enter Email" required>
             <input type="password" name="password" placeholder="Type Password" required>
             <input type="password" name="co-password" placeholder="Confirm Password" required>
             <button type="submit" name="submit" class="btnn">Register</button>

             <p class="link">Already have an account?<span>
             <a href="index.php">Login</a></p></span>
        </form>
    </div>



    <footer>
        <p><marquee scrollamount="10" behavior="alternate">&copy; 2024 IFM Tracking Web</marquee></p>
    </footer>
    
</body>
</html>
