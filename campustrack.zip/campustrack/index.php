<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IFM Tracking Web</title>
    <link href="style.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <header>
        <h1>IFM Tracking Web</h1>
    </header>

    <nav>
        <a href="found.php">Found Items</a>
        <a href="lost.php">Report Lost Item</a>
    </nav>


    <!-- Homepage content -->
    <!--<div class="container">-->
     <div class="video">
            <video class="video" autoplay loop muted plays-inline>
             <source src="pup7.mp4" type="video/mp4">
            </video>
     </div>
        <div class="homepage-description">
            <h2 style="padding-left:20px;color:white;max-width:550px;font-size:23px;">
            Welcome to the IFM Tracking Web platform!</h2>
            <p>This website provides a convenient way for students and staff to report lost items and retrieve found belongings. 
            Whether you've misplaced your keys, phone, or any other personal item, or if you've found something, 
            use our simple forms to get connected with the lost and found community on campus.</p><span>
            <h3 style="margin-bottom:30px;" ><a href="register.php" style="text-decoration:none;padding:10px;margin-left:13rem;"
             class="btnn">Register Now</a></h3></span>
        </div>
    </div>

    

    <?php 
require "functions.php";
logUser();
?>


    <div class="form">
        <form action="" method="POST">
             <h2>Login Here</h2>
             <input type="text" name="username" placeholder="Username" required>
             <input type="password" name="password" placeholder="Password" required>
             <button type="submit" name="submit" class="btnn">Login</button>

             <p class="link">Don't have an account?<span>
             <a href="register.php">Sign Up</a></p></span>
         </form>
    </div>



    <footer>
        <p><marquee scrollamount="10" behavior="alternate">&copy; 2024 IFM Tracking Web</marquee></p>
    </footer>
    
</body>
</html>
