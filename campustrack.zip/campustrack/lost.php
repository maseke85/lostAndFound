<?php

include("functions.php");
check_login();
reportLost();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campus Tracking Web</title>
    <link href="style.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <header>
        <h1>IFM Tracking Web</h1>
    </header>

    <nav>
        <a href="found.php">Found Items</a>
        <a href="dash.php">Dashboard</a>
    </nav>

    <div class="video">
            <video class="video" autoplay loop muted plays-inline>
             <source src="blaq.mp4" type="video/mp4">
            </video>
     </div>

 <!-- Form for reporting a lost item -->
     <div class="form-lost">
        <form action="" enctype="multipart/form-data" method="POST">
          <h2>Report a Lost Item</h2>

            <input type="text" name="lostname" placeholder="Item Name" required><br>
            <textarea name="lostdescription" required placeholder="Description"></textarea>        
            <input type="text" name="lostLocation" placeholder="Last Known Location" required>
            <input style="color:#fff;background-color:transparent;font-size:13px;margin-top:-15px;border:none;padding:25px;" 
            type="file" name="lostimage" placeholder="Upload Image" accept="image/*">
            <button style="margin-top:2px;" type="submit" name="submitt" class="btnn">Report Here</button>
             <p class="link">Have you already reported lost item(s)?<span>
             <a href="dash.php">Track Now</a></p></span>
        </form>
    </div>
</body>
</html>
