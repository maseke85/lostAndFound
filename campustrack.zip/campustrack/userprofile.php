<?php
include("functions.php");
check_login();
$row = $_SESSION['infos'];

	if($_SERVER['REQUEST_METHOD'] == "POST" && !empty($_POST['action']) && $_POST['action'] == 'delete')
	{
		//delete your profile
		$id = $_SESSION['info']['user_id'];
		$query = "delete from users where user_id = '$id' limit 1";
		$result = mysqli_query($con,$query);

		if(file_exists($_SESSION['info']['image'])){
			unlink($_SESSION['infos']['image']);
		}

		$query = "delete from posts where user_id = '$id'";
		$result = mysqli_query($con,$query);

		header("Location: logout.php");
		die;

	}
	if($_SERVER['REQUEST_METHOD'] == "POST" && !empty($_POST['username']))
	{
		//profile edit
		$image_added = false;
		if(!empty($_FILES['image']['name']) && $_FILES['image']['error'] == 0 && $_FILES['image']['type'] == "image/jpeg"){
			//file was uploaded
			$folder = "uploads/";
			if(!file_exists($folder))
			{
				mkdir($folder,0777,true);
			}

			$image = $folder . $_FILES['image']['name'];
			move_uploaded_file($_FILES['image']['tmp_name'], $image);

			if(file_exists($_SESSION['infos']['image'])){
				unlink($_SESSION['infos']['image']);
			}

			$image_added = true;
		}

		$username = addslashes($_POST['username']);
		$email = addslashes($_POST['email']);
		$password = addslashes($_POST['password']);
		$id = $_SESSION['infos']['user_id'];

		if($image_added == true){
			$query = "update users set username = '$username',email = '$email',password = '$password',image = '$image' where user_id = '$id' limit 1";
		}else{
			$query = "update users set username = '$username',email = '$email',password = '$password' where user_id = '$id' limit 1";
		}

		$result = mysqli_query($con,$query);

		$query = "select * from users where user_id = '$id' limit 1";
		$result = mysqli_query($con,$query);

		if(mysqli_num_rows($result) > 0){

			$_SESSION['infos'] = mysqli_fetch_assoc($result);
		}

		header("Location: userprofile.php");
		die;
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link href="style.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <header>
        <h3>IFM Tracking Web</h3>
    </header>

    <nav>
        <a style="border-bottom: 5px solid #ff7200;padding:11px;margin-top:6px;margin-right:25px;" href="dash.php">
        <span style="padding:2px;margin-bottom:20px;">DASHBOARD</span>
        
        
        </a>
        <a href="found.php">FOUND ITEMS</a>
        <a href="lost.php">REPORT LOST ITEM(S)</a>
    </nav>

    <!-- Homepage content -->
    <!--<div class="container">-->
        <!--<div class="video">
            <video class="video" autoplay loop muted plays-inline>
             <source src="pup.mp4" type="video/mp4">
            </video>
        </div>-->
             <div class="hello">
              <h1><marquee scrollamount="5" behavior="alternate">
                Welcome, <?php echo $row['username']; ?>!</marquee></h1>
             </div>
             <h3 style="margin-top:-30px;text-align:center;padding:20px;font-family:monospace;color:blue;font-size:20px;">
             UPDATE PROFILE:<hr></h3>

			<?php if(!empty($_GET['action']) && $_GET['action'] == 'edit'):?>

				<form method="post" enctype="multipart/form-data" style="margin-right:16rem;margin-top:-75px;padding:15px;">
					<img src="<?php echo $_SESSION['infos']['image']?>" style="margin-top:15px;width:150px;height:150px;border-radius:15px;object-fit: cover;margin-left:10rem;display: block;">
					Update image: <input type="file" name="image"><br>
					<input style="width: 80%;" value="<?php echo $_SESSION['infos']['username']?>" type="text" name="username" placeholder="Username" required><br>
					<input style="width: 80%;" value="<?php echo $_SESSION['infos']['email']?>" type="email" name="email" placeholder="Email" required><br>
					<input style="width: 80%;" value="<?php echo $_SESSION['infos']['password']?>" type="text" name="password" placeholder="Password" required><br>

					<button style="cursor:pointer;padding:6px; border-radius:5px; color:#fff;font-family:monospace;font-size:15px;background: #3c5a99; border: 2px solid #ff7200">Save</button>
					<a href="userprofile.php">
						<button type="button" style="cursor:pointer;padding:6px;border-radius:5px;font-family:monospace;color:#fff;font-size:15px;background:#3c5a99; border: 2px solid #ff7200">Cancel</button>
					</a>
				</form>

			<?php elseif(!empty($_GET['action']) && $_GET['action'] == 'delete'):?>

				<h2 style="text-align:center;margin-top:-20px;">Are you sure you want to delete your profile??</h2>

				<div style="margin: auto;max-width: 600px;text-align: center;">
					<form method="post" style="margin: auto;padding:10px;">
						
						<img src="<?php echo $_SESSION['infos']['image']?>" style="width:200px;height:200px;object-fit:cover;margin:auto;display: block;">
						<div><?php echo $_SESSION['infos']['username']?></div>
						<div><?php echo $_SESSION['infos']['email']?></div>
						<input type="hidden" name="action" value="delete">
						<button style="cursor:pointer;padding:4px;border-radius:5px;font-family:monospace;color:#fff;font-size:15px;
						background:#3c5a99; border: 2px solid #ff7200">Delete</button>
						<a href="userprofile.php">
							<button style="cursor:pointer;padding:4px;border-radius:5px;font-family:monospace;color:#fff;font-size:15px;
							background:#3c5a99; border: 2px solid #ff7200" type="button">Cancel</button>
						</a>
					</form>
				</div>
				<br>
				<?php else:?>
				<div style="margin: auto;max-width: 600px;text-align: center;margin-top:-72px;">
					<div>
						<td><img src="<?php echo $_SESSION['infos']['image']?>" style="border-radius:10px;margin-top:20px;width:300px;height:300px;object-fit:cover;"></td>
				</div>
                    <div class="btnedit">
					  <a style="padding:10px;" href="userprofile.php?action=edit">
					  <button style="cursor:pointer;background:#ff7200;color:#fff;border:none;padding:8px;border-radius:8px;">Edit profile</button></a>

					  <a style="padding:10px;" href="userprofile.php?action=delete">
						<button style="cursor:pointer;background:red;color:#fff;border:none;margin-top:5px;padding: 8px;border-radius:8px;">Delete profile</button>
					  </a>
            </div>
			</div>
			<?php endif;?>
			

             




        <footer style="height:30px;">
          <p style="margin-top:7px;"><marquee scrollamount="15" direction="right" behavior="scroll">&copy; 2024 IFM Tracking Web</marquee></p>
        </footer>
    
</body>
</html>
