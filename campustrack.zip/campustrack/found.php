<?php
include("functions.php");
check_login();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campus Tracking Web</title>
    <link href="style.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body style="margin:0;padding:0;background-color:#ffff;">
    <header style="">
        <h1>IFM Tracking Web</h1>
    </header>

    <nav>
        <a style="font-family:tahoma;font-weight:100;" href="dash.php">Dashboard</a>
    </nav>
    

    <?php 

	

	if($_SERVER['REQUEST_METHOD'] == "POST" && !empty($_POST['action']) && $_POST['action'] == 'post_delete')
	{
		//delete your post
		$id = $_GET['id'] ?? 0;
		$user_id = $_SESSION['infos']['user_id'];

		$query = "SELECT * FROM found_items WHERE found_item_id = '$id' && user_id = '$user_id' LIMIT 1";
		$result = mysqli_query($con,$query);
		if(mysqli_num_rows($result) > 0){

			$row = mysqli_fetch_assoc($result);
			if(file_exists($row['image_url'])){
				unlink($row['image_url']);
			}

		}

		$query = "DELETE FROM found_items WHERE found_item_id = '$id' && user_id = '$user_id' limit 1";
		$result = mysqli_query($con,$query);

		header("Location: found.php");
		die;

	}
	elseif($_SERVER['REQUEST_METHOD'] == "POST" && !empty($_POST['action']) && $_POST['action'] == "post_edit")
	{
		//post edit
		$id = $_GET['id'] ?? 0;
		$user_id = $_SESSION['infos']['user_id'];

		$image_added = false;
		if(!empty($_FILES['image']['name']) && $_FILES['image']['error'] == 0 && $_FILES['image']['type'] == "image/jpeg"){
			//file was uploaded
			$folder = "uploads/";
			if(!file_exists($folder))
			{
				mkdir($folder,0777,true);
			}

			$image = $folder . $_FILES['image']['name'];
			move_uploaded_file($_FILES['image']['tmp_name'], $image);

				$query = "SELECT * FROM found_items WHERE found_item_id = '$id' && user_id = '$user_id' LIMIT 1";
				$result = mysqli_query($con,$query);
				if(mysqli_num_rows($result) > 0){

					$row = mysqli_fetch_assoc($result);
					if(file_exists($row['image_url'])){
						unlink($row['image_url']);
					}

				}

			$image_added = true;
		}

		$found = addslashes($_POST['itname']);

		if($image_added == true){
			$query = "UPDATE found_items SET found_item_name = '$found, image = '$image' WHERE found_item_id = '$id' && user_id = '$user_id' LIMIT 1";
		}else{
			$query = "UPDATE found items SET found_item_name = '$found' WHERE found_item_id = '$id' && user_id = '$user_id' LIMIT 1";
		}

		$result = mysqli_query($con,$query);
 
		header("Location: found.php");
		die;
	}
	elseif($_SERVER['REQUEST_METHOD'] == "POST" && !empty($_POST['itname']))
	{
		           //adding post

		$image = "";
		if(!empty($_FILES['image']['name']) && $_FILES['image']['error'] == 0 && $_FILES['image']['type'] == "image/jpeg"){
			
			       //file was uploaded
			$folder = "uploads/";
			if(!file_exists($folder))
			{
				mkdir($folder,0777,true);
			}

			$image = $folder . $_FILES['image']['name'];
			move_uploaded_file($_FILES['image']['tmp_name'], $image);
 
		}

		$itemName = addslashes($_POST['itname']);
		$dsc = addslashes($_POST['dsc']);
		$cont = addslashes($_POST['cont']);
		$location = addslashes($_POST['location']);
		$user_id = $_SESSION['infos']['user_id'];
		$date = date('Y-m-d H:i:s');

		$query = "INSERT INTO found_items (user_id,item_name,item_description,location_found,image_url,date_reported,contacts)
	    VALUES ('$user_id','$itemName', '$dsc', '$location', '$image','$date', '$cont')";

		$result = mysqli_query($con,$query);
 
		header("Location: found.php");
		die;
	}


?>

		<div style="margin: auto;max-width: 600px">

			<?php if(!empty($_GET['action']) && $_GET['action'] == 'post_delete' && !empty($_GET['id'])):?>
				
				<?php 
					$id = (int)$_GET['id'];
					$query = "SELECT * FROM found_items WHERE found_item_id = '$id' LIMIT 1";
					$result = mysqli_query($con,$query);
				?>

				<?php if(mysqli_num_rows($result) > 0):?>
					<?php $row = mysqli_fetch_assoc($result);?>
					
					<h3>Are you sure you want to delete this post?!</h3>
					<form method="post" action="found.php" enctype="multipart/form-data" style="margin: auto;padding:10px;">
						
						<img src="<?=$row['image']?>" style="width:100%;height:200px;object-fit: cover;"><br>
						<div><?=$row['post']?></div><br>
						<input type="hidden" name="action" value="post_delete">

						<button>Delete</button>
						<a href="found.php">
							<button type="button">Cancel</button>
						</a>
					</form>
				<?php endif;?>
			<?php elseif(!empty($_GET['action']) && $_GET['action'] == 'post_edit' && !empty($_GET['id'])):?>

				<?php 
					$id = (int)$_GET['found_item_id'];
					$query = "SELECT * FROM found_items WHERE found_item_id = '$id' limit 1";
					$result = mysqli_query($con,$query);
				?>

				<?php if(mysqli_num_rows($result) > 0):?>
					<?php $row = mysqli_fetch_assoc($result);?>
					<h5>Edit a Post</h5>
					<form method="post" enctype="multipart/form-data" style="margin: auto;padding:10px;">
						
						<img src="<?=$row['image']?>" style="width:100%;height:200px;object-fit: cover;"><br>
						image: <input type="file" name="image"><br>
						<textarea name="post" rows="8"><?=$row['item_description']?></textarea><br>
						<input type="hidden" name="action" value="post_edit">

						<button style="padding: 6px; border-radius: 5px; color: #fff; font-size: 13px; background: #3c5a99; border: 3px solid #0ef">Save</button>
						<a href="found.php">
							<button style="padding: 6px; border-radius: 5px; color: #fff; font-size: 13px; background: #3c5a99; border: 3px solid #0ef" type="button">Cancel</button>
						</a>
					</form>
				<?php endif;?>
				</div>

			<?php else:?>			
				<br>
				<hr>
				<h5 style="text-align:center;color:#ff7200;font-family:monospace;font-size:23px;">Report an item you found:</h5>

				<form method="post" action="found.php" enctype="multipart/form-data" style="margin:auto;padding:2px;">
					<input style="border-radius:10px;padding:14px;border:1px solid #3c5a99;font-size:16px;" type="text" name="itname" placeholder="Name of an Item*" required>
					<input style="border-radius:10px;padding:14px;border:1px solid #3c5a99;font-size:16px;" type="text" name="location" placeholder="Location Found*" required>
					<input style="border-radius:10px;padding:14px;border:1px solid #3c5a99;font-size:16px;" type="text" name="cont" placeholder="Enter your contacts*" required>
					<textarea style="border-radius:10px;margin-left:-2px;justify-content:center;border:1px solid #3c5a99;font-size:16px;" name="dsc" rows="8" placeholder="Briefly, explain an item you found*"></textarea><br>
					<h5 style="margin-bottom:13px;font-weight:100;font-family:monospace;font-size:15px;margin-top:-8px;">Upload item's photo (optional)</h5> <input style="margin-left:-10px;" type="file" name="image"><br>

					<button type="submit" name="submit" style="margin-bottom:10px;padding:6px;border-radius:9px;color:#fff; font-size:13px;background:#ff7200;cursor:pointer;border:2px solid #3c5a99;">Report</button>
	
				</form>

				<hr>
				<posts>
					<h5 style="margin-top:35px;margin-bottom:20px;font-family:monospace;font-size:15px;color:blue;">Found item posted</h5>
					<?php 
						//$id = $_SESSION['infos']['user_id'];
						$query = "SELECT * FROM found_items JOIN users ON found_items.user_id = users.user_id 
						ORDER BY found_item_id DESC LIMIT 50";

						$result = mysqli_query($con,$query);
					?>

					<?php if(mysqli_num_rows($result) > 0):?>

						<?php while ($row = mysqli_fetch_assoc($result)):?>
							<div style="width:auto;background-color:#fff;display:flex;border:solid thin #aaa;border-radius:6px;margin-bottom:10px;margin-top:10px;">
								<div style="flex:1;text-align:center;">
							    	
									<img src="<?=$row['image']?>" style="border-radius:40%;margin:7px;width:25px;height:25px;object-fit: cover;">
									
									
								</div>
								   <div style="margin-left:-12px;margin-top:-16px;padding: 2px;">
								    <h4 style="color:#ff7200;font-size:16px;"><?=$row['username']?></h4>
							       </div>
								   <br>
								<div style="flex:9">
								   <div style="position:static;margin-top:38px;margin-left:-78px;font-family:tahoma;font-weight:200;font-size:17px;">ItemName: <?php echo $row['item_name'];?></div>
								   <p style="margin-top:1px;margin-left:-78px;font-family:tahoma;font-weight:200;font-size:17px;">Location: <?php echo $row['location_found'];?></p>
								   <p style="margin-top:-16px;margin-left:-78px;font-family:tahoma;font-weight:200;font-size:17px;">Contacts: <?php echo $row['contacts'];?></p>
								   <p style="margin-top:-16px;margin-left:-78px;font-family:tahoma;font-weight:200;font-size:17px;width:285px;position:static;">Description: <?php echo $row['item_description'];?></p>
									<?php if(file_exists($row['image_url'])):?>
										<div style="">
											<img src="<?=$row['image_url']?>" style="position:static;border-radius:10px;width:150px;height:150px;margin-top:-150px;margin-left:19rem;object-fit: cover;">
										</div>
									<?php endif;?>
									<div>
										<div style="position:static;margin-bottom:13px;font-family:tahoma;font-weight:200;margin-top:-13px;color:black;font-size:17px; margin-left:-78px; ">Date found: <?= date("M j, Y   H:i:A",strtotime($row['date_reported']))?></div>
										<br>
									</div>
								</div>
								
							</div><br>
						<?php endwhile;?>
					<?php endif;?>
				</posts>
			<?php endif;?>

		</div>

</body>
</html>