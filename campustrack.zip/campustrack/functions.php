<?php 
require "connection.php";

function check_login()
{
	 global $con;

	if(empty($_SESSION['infos'])){

		header("Location: index.php");
		//echo '<div class="message">Please Login to continue';
		die;
	}
}

function reportLost()
{	
	if(isset($_POST['submitt']))
	{
		global $con;
    $userID = $_SESSION['infos']['user_id'];
	  $itemName = $_POST['lostname'];
	  $desc = $_POST['lostdescription'];
	  $location = $_POST['lostLocation'];
	  //$image = $_POST['lostimage'];
	  $date = date('Y-m-d H:i:s');

    $sql = "INSERT INTO lostitems(item_name, user_id, item_description, last_known_location, date_reported) 
	  VALUES('$itemName', '$userID', '$desc', '$location', '$date')";
	  $result = mysqli_query($con,$sql);

	  echo '<div class="message-suc">Item Reported successfully!</div>';
    header("Location: dash.php");

	}
}

function regUser()
{
	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
	    global $con;
		$username = htmlspecialchars($_POST['username']);
		$email = htmlspecialchars($_POST['email']);
		$password = htmlspecialchars($_POST['password']);
		$co_password = htmlspecialchars($_POST['co-password']);

            //verifying the unique email & username
         $verify_email = mysqli_query($con,"SELECT email FROM users WHERE email='$email'");
         $verify_username = mysqli_query($con,"SELECT username FROM users WHERE username='$username'");

           if(strlen($password) < 6 )
		    {
              echo '<div class="message-pwd">Password should be atleast 6 characters!</div>';
            }

        else if($co_password != $password )
		    {
              echo '<div class="message-pwd">Passwords does not match!</div>';
            }
            
        else if(mysqli_num_rows($verify_email) !=0 )
		    {
              echo '<div class="message-eml">Email already exist</div>';
            }

         else if(mysqli_num_rows($verify_username) !=0 )
		    {
              echo '<div class="message-usr">Username already taken</div>';
            }

       else{
              $query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email','$password')";
              $result = mysqli_query($con,$query);
              echo '<div class="message-suc">Registration successfully!</div>';
			  echo "<script>window.open('index.php', '_self')</script>";
    
            }

    
       
	}
}

function logUser()
{
	  if($_SERVER['REQUEST_METHOD'] == "POST")
        {
         global $con;
         $username = addslashes($_POST['username']);
         $password = addslashes($_POST['password']);

         $query = "SELECT * FROM users WHERE username = '$username' && password = '$password' limit 1";

         $result = mysqli_query($con,$query);
  
         if(mysqli_num_rows($result) > 0)
          {
            $row = mysqli_fetch_assoc($result);

            $_SESSION['infos'] = $row;
            header("Location: dash.php");
            die;
          }else{
                echo '<div class="message">Wrong Username or Password</div>';
               }
    
        }
}


function recentPost()
{
     global $con;
     $id = $_SESSION['infos']['user_id'];
		 $query = "SELECT * FROM lostitems JOIN users ON 
     lostitems.user_id = users.user_id ORDER BY lost_item_id DESC LIMIT 50";
		 $result = mysqli_query($con,$query);

  if(mysqli_num_rows($result) > 0)
    {
      $itemRow = mysqli_fetch_assoc($result);
        while($itemRow = mysqli_fetch_assoc($result)){
          echo "<br><img style='width:25px;height:25px;border-radius:12px;'' src='{$itemRow['image']}' alt='{$itemRow['image']}' Image'>";
          echo '<span style="position:absolute;margin-left:7px;font-family:monospace;font-size:20px;color:#ff7200;">' . $itemRow['username'] . '</span>';
          echo '<p class="container-items">Item name: ' . $itemRow['item_name'] . '</p>';
          echo '<h5 class="container-items">Description: ' . $itemRow['item_description'] . '</h5>';
          echo '<p class="container-items">Last location: ' . $itemRow['last_known_location'] . '</p>';
          echo '<p class="container-items">Contacts: ' . $itemRow['contacts'] . '</p>';
          echo '<p class="container-items">Date reported: ' . $itemRow['date_reported'] . '</p><br><br><hr><br>';
        }
     }
     //die();


}


function search()
{
     if(isset($_GET['srchsubmit']))
   {
     $srchtxt = $_GET['srchtxt'];
     global $con;
     $sql = "SELECT * FROM lostitems WHERE item_name LIKE '%$srchtxt%' OR 
     last_known_location LIKE '%$srchtxt%' OR contacts LIKE '%$srchtxt%' OR
     item_description LIKE '%$srchtxt%' UNION SELECT * FROM found_items WHERE item_name LIKE '%$srchtxt%' OR 
     item_description LIKE '%$srchtxt%' ORDER BY item_name DESC LIMIT 50";
     $res = mysqli_query($con,$sql);
     $num_results = mysqli_num_rows($res);
     //echo "<p>$num_results</p>";
     if(mysqli_num_rows($res) > 0 )
      {
        $row = mysqli_fetch_assoc($res);
        echo '<h4 style="font-weight:100;font-family:tahoma;color:green;margin-bottom:-15px;padding:4px;margin-left:3.7rem;">Results</h4><br>';
          while($row = mysqli_fetch_assoc($res))
          {
            echo '<p>Item Name: ' . $row['item_name'] . '</p>';
            echo '<p>Description: ' . $row['item_description'] . '</p>';
            echo '<p>Location: ' . $row['last_known_location'] . '</p>';
            echo '<p>Contacts: ' . $row['contacts'] . '</p>';
          }
          mysqli_free_result($res);
      }
       else
      {
        echo "<p style='';'>No results found for <h5 style='padding:1px;position:absolute;margin-left:12.6rem;font-family:tahoma;font-style:italic;font-weight:100;color:red;font-size:16px;'>'$srchtxt'</h5></P>";
      }
    }

}
