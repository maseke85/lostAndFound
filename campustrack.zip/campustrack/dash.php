<?php
include("functions.php");
check_login();

$row = $_SESSION['infos'];
?>

<!DOCTYPE html>
<!-- Website - www.codingnepalweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <title>IFM Tracking Web | Dashboard</title>
    <link rel="stylesheet" href="dashstyle.css" />
    <!-- Boxicons CDN Link -->
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>
  <body>
    <div class="sidebar">
      <div class="logo-details">
        <span class="logo_name">MENU</span>
      </div>
      <ul class="nav-links">
        <li>
          <a href="userprofile.php" class="active">
            <i class="bx bx-grid-alt"></i>
            <span class="links_name">PROFILE</span>
          </a>
        </li>
        <li>
          <a href="lost.php">
            <i class="bx bx-list-ul"></i>
            <span class="links_name">REPORT LOST ITEM(S)</span>
          </a>
        </li>
        <li>
          <a href="found.php">
            <i class="bx bx-book-alt"></i>
            <span class="links_name">FOUND ITEMS</span>
          </a>
        </li>
      </ul>
    </div>
    <section class="home-section">
      <nav>
        <div class="sidebar-button">
          <i class="bx bx-menu sidebarBtn"></i>
          <span class="dashboard">User | Dashboard</span>
        </div>
        <div class="search-box">
          <form class="search-box" action="dash.php" method="GET">
            <input type="text" name="srchtxt" placeholder="Search Here" required>
            <button type="submit" name="srchsubmit">
            <i style="font-size:11px;" 
            class="bx bx-search">Search</i></button>
          </form>
        </div>
        <div class="profile-details">
          <a style="color:red;text-decoration:none;" href="logout.php">
          <span class="admin_name"><img src="images/logout2.jpg" alt="" /></span></a>
        </div>
      </nav>

      <div class="home-content">
        <div class="overview-boxes">
          <div class="box">
            <div class="right-side">
            <div class="number">Welcome, <?php echo $row['username']; ?>!</div>
            </div>
          </div>
        </div>

        <div class="sales-boxes">
          <div class="recent-sales box">
            <div class="title">Recent Lost items reported:
              <p style="padding-top:6px;"></p>
              <?php recentPost(); ?>
            </div>
          </div>
        </div>
        <div class="searched">
          <?php search();?>
          
        </div>
        
      </div>

    </section>

    <script>
      let sidebar = document.querySelector(".sidebar");
      let sidebarBtn = document.querySelector(".sidebarBtn");
      sidebarBtn.onclick = function () {
        sidebar.classList.toggle("active");
        if (sidebar.classList.contains("active")) {
          sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
        } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
      };
    </script>

  </body>
</html>
