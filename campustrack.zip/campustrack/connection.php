<?php
session_start();

$con = mysqli_connect("127.0.0.1:3307", "root", "", "campustrack");

if(!$con){
    die("Connection failed" . mysqli_connect_error());
    
mysqli_close($con);
}



?>